-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Сен 11 2020 г., 10:42
-- Версия сервера: 8.0.14
-- Версия PHP: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `phpgb`
--

-- --------------------------------------------------------

--
-- Структура таблицы `galary`
--

DROP TABLE IF EXISTS `galary`;
CREATE TABLE IF NOT EXISTS `galary` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `path_small` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `path` varchar(255) COLLATE utf8_bin NOT NULL,
  `size` int(11) DEFAULT NULL,
  `viewed` int(8) DEFAULT NULL,
  `likes` int(8) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Дамп данных таблицы `galary`
--

INSERT INTO `galary` (`id`, `name`, `path_small`, `path`, `size`, `viewed`, `likes`) VALUES
(11, '1.jpg', 'thumb/1.jpg', 'img/1.jpg', NULL, 4, NULL),
(12, '2.jpg', 'thumb/2.jpg', 'img/2.jpg', NULL, 3, NULL),
(13, '3.jpg', 'thumb/3.jpg', 'img/3.jpg', NULL, 15, NULL),
(14, '4.jpg', 'thumb/4.jpg', 'img/4.jpg', NULL, 3, NULL),
(15, '5.jpg', 'thumb/5.jpg', 'img/5.jpg', NULL, 5, NULL),
(16, '6.jpg', 'thumb/6.jpg', 'img/6.jpg', NULL, 5, NULL),
(18, '6 - Copy.jpg', 'thumb/6 - Copy.jpg', 'img/6 - Copy.jpg', NULL, 4, NULL);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
